
shinyServer(
  
  function(input, output) {
    
   
    
    output$disp_1 <- renderPlot({
      
      x    <- airquality$Ozone
      x    <- na.omit(x)
      
      bins <- seq(min(x), max(x), length.out = input$bins + 1)
      
      hist(x, breaks = bins, col = 'green', border = "black",
           xlab = "Ozone levels",
           main = "Histogram of Ozone levels")
      
    })
    
  }
)

