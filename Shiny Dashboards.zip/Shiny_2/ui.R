#install.packages("shiny")
library(shiny)
#setwd("~/Desktop/Intro to R/Shiny_2")


shinyUI(
  
  pageWithSidebar(
  
    headerPanel("Ozone levels Histogram Shiny App Coding Dojo"),
    
    sidebarPanel(
        sliderInput(inputId = "bins", label = "Number of bins in my Histogram:",
                    min = 1, max = 30, value = 15)),
      
      mainPanel(plotOutput(outputId = "disp_1"),
               
                )
    )

)