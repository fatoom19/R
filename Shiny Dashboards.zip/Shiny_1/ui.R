#install.packages("shiny")
library(shiny)
#setwd("~/Desktop/Intro to R/Shiny_1")


shinyUI(
  pageWithSidebar(
    
    headerPanel("Shiny App Demo"),
    
    sidebarPanel(
      selectInput("Distribution", "Please Select Distribution Type",
                  choices= c("Normal", "Exponential")),
      
      selectInput("PlotColor", "Please Select Plot Color",
                  choices = c("blue", "green", "red")),
      
      sliderInput("sampleSize", "Please Select Sample Size",
                  min = 100, max = 5000, value = 1000, step = 300),
      
      conditionalPanel(condition = "input.Distribution == 'Normal' ",
                       textInput("Mean", "Please Select The Mean", 10),
                       textInput("sd", "Please Select The Standard Deviation", 3)),
      
      conditionalPanel(condition = "input.Distribution == 'Exponential' ",
                       textInput("lambda", "Please Select Exponentail Lambda", 1)),
                       
      textInput("PlotTitle", "Please Enter Plot Title", "Histogram")
      

    ),
    
    mainPanel(plotOutput("dispPlot"))
  )
  
)


