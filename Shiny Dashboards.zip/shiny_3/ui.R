#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)


# Define UI for application that draws a histogram
shinyUI(fluidPage(

    # Application title
    titlePanel("Iris Dataset"),

    # Sidebar with a slider input for number of bins
    sidebarLayout(
        sidebarPanel(
          selectInput("SpeciesType", "Please Select The Species",
                      choices = c("setosa", "versicolor", "virginica")),
          
          radioButtons("checkColor", label = h3("Select scatter plot shape"), 
                             choices = list("dots" = 1, "solid dots" = 19, "plus" = 3),
                             selected = 1),
          textInput("color_hexcode", label = h3("Enter hex code for the histogram desired color"), value = "red"),
            
        ),
        
        

        # Show a plot of the generated distribution
        mainPanel(
            plotOutput("plot_1"),
            plotOutput("plot_2"),
        )
    )
))
