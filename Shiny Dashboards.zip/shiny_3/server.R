#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(datasets)
library(tidyverse)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
  
  
    output$plot_1 <- renderPlot({
      filtered_iris <- iris %>% filter(iris$Species == input$SpeciesType)
        
        plot(filtered_iris$Petal.Length, filtered_iris$Petal.Width,
             col = "#cc0000",  
             pch = as.numeric(input$checkColor),         
             main = paste("Petal Length vs. Petal Width for", input$SpeciesType),
             xlab = "Petal Length cm",
             ylab = "Petal Width cm")
      

    })
    
    output$plot_2 <- renderPlot({
      
      
      hist(iris$Petal.Width [iris$Species == input$SpeciesType],
           xlim = c(0, 3),
           breaks = 9,
           main = paste("Petal Width for", input$SpeciesType),
           xlab = "",
           col = input$color_hexcode)
      
    })

})
